   DEVELOPER: NAYEEM
   USAGE:
      * Install the app!
      * Launch it from the app drawer!
      * Open your file manager!
      * You will see that it has been cleared! 

   NOTICE:
      * Dont use this software for illegal activity!
      * I am not responsible for any reason of damages of your sdcard & mountpoint!